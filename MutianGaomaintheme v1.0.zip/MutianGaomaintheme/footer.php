<footer id="colophon" class="site-footer">
    <div class="site-info">
        <div class="left-info">
            <?php
            printf(
                esc_html__('%1$s', 'mutiangao'),
                'MillenniumGamesInc.'
            );
            ?>
        </div>
        <div class="right-info">
            <?php
            printf(
                esc_html__('%1$s', 'mutiangao'),
                '<a href="https://wordpress.org/" rel="generator">自豪地采用 WordPress</a>'
            );
            ?>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>